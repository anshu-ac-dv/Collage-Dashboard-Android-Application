package com.anshu.admincollage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class UploadPdfActivity extends AppCompatActivity {
    private CardView addPdf;
    private final int REQ=1;
    private Uri pdfData;
    private EditText pdfTitle;
    private Button uploadPdfBtn;
    private DatabaseReference referance;
    private StorageReference storageReferance;
    String downloadUrl = "";
    private ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_pdf);
        referance = FirebaseDatabase.getInstance().getReference();
        storageReferance = FirebaseStorage.getInstance().getReference();

        pd = new ProgressDialog(this);
        addPdf = findViewById(R.id.addPdf);
        pdfTitle = findViewById(R.id.pdgTitle);
        uploadPdfBtn = findViewById(R.id.uploadPdfBtn);

        addPdf.setOnClickListener((view )-> { openGallery();});
    }
    private void openGallery() {
       Intent intent = new Intent();
       intent.setType("pdf");
       intent.setAction(Intent.ACTION_GET_CONTENT);
       startActivityForResult(Intent.createChooser(intent,"Select PDF File"),REQ);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQ && resultCode == RESULT_OK) {
            pdfData = data.getData();
            Toast.makeText(this, "PDFData", Toast.LENGTH_SHORT).show();
        }
        }
    }
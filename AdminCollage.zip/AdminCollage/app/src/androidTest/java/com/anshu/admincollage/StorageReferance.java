package com.anshu.admincollage;

public class StorageReferance {
}
